// Coppyright Igor Rusakov

#pragma once

#include "CoreMinimal.h"
#include "AbilitySystem/Abilities/AuraDamageGameplayAbility.h"
#include "AuraMelleeAttack.generated.h"

/**
 * 
 */
UCLASS()
class AURA_API UAuraMelleeAttack : public UAuraDamageGameplayAbility
{
	GENERATED_BODY()
	
};
